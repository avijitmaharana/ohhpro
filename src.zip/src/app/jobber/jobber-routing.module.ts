import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { JobberComponent } from './jobber.component';
import { JobberDashboardComponent } from './site/jobber-dashboard/jobber-dashboard.component';

const routes: Routes = [
  { path: '', component: JobberComponent, children: [
    { path: '', component: JobberDashboardComponent }
  ]}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class JobberRoutingModule {}
