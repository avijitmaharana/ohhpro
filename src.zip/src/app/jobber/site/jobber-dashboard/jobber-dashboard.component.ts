import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jobber-dashboard',
  templateUrl: './jobber-dashboard.component.html',
  styleUrls: ['./jobber-dashboard.component.scss']
})
export class JobberDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
