import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { JobberRoutingModule } from './jobber-routing.module';
import { JobberComponent } from './jobber.component';
import { HeaderComponent } from './layouts/header/header.component';
import { FooterComponent } from './layouts/footer/footer.component';
import { JobberDashboardComponent } from './site/jobber-dashboard/jobber-dashboard.component';

@NgModule({
  declarations: [
    JobberComponent,
    HeaderComponent,
    FooterComponent,
    JobberDashboardComponent
  ],
  imports: [
    RouterModule,
    JobberRoutingModule
  ],
  exports: [RouterModule]
})

export class JobberModule {}
