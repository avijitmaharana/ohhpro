import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jobber',
  templateUrl: './jobber.component.html',
  styleUrls: ['./jobber.component.scss']
})
export class JobberComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
