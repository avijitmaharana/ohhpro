import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { CustomerRoutingModule } from './customer-routing.module';
import { CustomerComponent } from './customer.component';
import { HeaderComponent } from './layouts/header/header.component';
import { FooterComponent } from './layouts/footer/footer.component';
import { CustomerDashboardComponent } from './site/customer-dashboard/customer-dashboard.component';

@NgModule({
  declarations: [
    CustomerComponent,
    HeaderComponent,
    FooterComponent,
    CustomerDashboardComponent
  ],
  imports: [
    RouterModule,
    CustomerRoutingModule
  ],
  exports: [RouterModule]
})

export class CustomerModule {}
