import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { HomeComponent } from './home.component';
import { HomeDashBoardComponent } from './site/home-dash-board/home-dash-board.component';
import { LoginComponent } from './site/login/login.component';
import { RegisterComponent } from './site/register/register.component';

const routes: Routes = [
  { path: '', component: HomeComponent, children: [
    { path: '', component: HomeDashBoardComponent },
    { path: 'login', component: LoginComponent },
    { path: 'register', component: RegisterComponent },
  ]}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class HomeRoutingModule {}
