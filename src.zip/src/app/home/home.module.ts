import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home.component';
import { HeaderComponent } from './layouts/header/header.component';
import { FooterComponent } from './layouts/footer/footer.component';
import { LoginComponent } from './site/login/login.component';
import { HomeDashBoardComponent } from './site/home-dash-board/home-dash-board.component';
import { RegisterComponent } from './site/register/register.component';

@NgModule({
  declarations: [
    HomeComponent,
    HeaderComponent,
    FooterComponent,
    LoginComponent,
    HomeDashBoardComponent,
    RegisterComponent
  ],
  imports: [
    RouterModule,
    HomeRoutingModule
  ],
  exports: [RouterModule]
})

export class HomeModule {}
